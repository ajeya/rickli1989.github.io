# Lab49 Widget Money Transfer

To use this:
* `cd MoneyTransfer`
* `npm install -g jspm gulp`
* `(sudo) npm install`
* `(sudo) jspm install`
* Run as development `export SITUATION=development && gulp` or just `gulp`
* Run as production `export SITUATION=production && gulp`
* `http://localhost:9000`
